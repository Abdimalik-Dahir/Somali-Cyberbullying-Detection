# train.py
# train.py
import os
import django
from django.conf import settings

# Configure Django settings
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'bullying_detection.settings')  # Replace 'your_project' with your project's name
django.setup()

import os
from detection.model import train_model

data_path = os.path.join(os.path.dirname(__file__), 'data', 'bullying_comments.xlsx')
train_model(data_path)
print('the data is: ',data_path)
# import joblib
# import os
# import re
# from .models import ClassificationHistory

# MODEL_PATH = os.path.join(os.path.dirname(__file__), 'model', 'bullying_detection_model.pkl')

# # Define your custom stop words
# my_stopwords = {'ku', 'iyo', 'uu', 'ha', 'ma', 'laga', 'ugu', 'waa', 'in', 'ee', 'aa', 'u', 'scw', 'si',
#                 'inay', 'la', 'ah', 'ka', 'ayaa', 'iska', 'wax', 'oo', 'soo', 'ayuu', 'bal', 'uga', 'aan',
#                 'wa', 'i', 'buu', 'inu', 'loo', 'waxaa', 'waxaan', 'ah', 'lama', 'maxay', 'tahay',
#                 'a', 'lagu', 'maxaa', 'inuu', 'wada', 'wuxuu', 'hala', 'e', 'waxan', 'sida', 'aad', 'kale', 
#                 'ah', 'wuu', 'ama', 'sii', 'hadii', 'ay', 'aya', 'siduu', 'yaa', 'ayu', 'way', 'naga', 'war',
#                 'ba', 'aha', 'iga', 'baa', 'ay', 'muxuu', 'maa', 'is', 'ayay', 'so', 'laha', 'haka', 'aya', 'wuxu',
#                 'haa', 'he', 'ilaa', 'hada', 'mida', 'may', 'waxa', 'waan', 'hadaad', 'waxay', 'kuma', 'wixii', 
#                 'inaad', 'og', 'sow', 'inta', 'haku', 'lahaa', 'inay', 'alx', 'kugu', 'yahay', 'kaa', 'miyaa',
#                 'miya', 'ayey', 'maxa', 'haduu', 'leh', 'ayan', 'hadi', 'iney', 'isku', 'lkn', 'alle', 'na', 'kuu'}

# # Function to preprocess text
# def preprocess_text(text):
#     text = re.sub('[^a-zA-Z]', ' ', text)
#     text = text.lower().split()
#     text = [word for word in text if word not in my_stopwords]
#     return ' '.join(text)

# # Load the model
# if os.path.exists(MODEL_PATH):
#     pipeline = joblib.load(MODEL_PATH)
# else:
#     pipeline = None

# def detect_bullying(text):
#     if pipeline:
#         processed_text = preprocess_text(text)
#         history_entry = ClassificationHistory.objects.filter(text=processed_text).first()
        
#         if history_entry and not history_entry.correct:
#             # If the text was incorrectly classified before, use the corrected prediction
#             prediction = history_entry.corrected_prediction
#             history_entry.correct = False  # Mark as correct now
#             history_entry.save()
#         else:
#             prediction = pipeline.predict([processed_text])[0]
#             prediction = 'bullying' if prediction == 1 else 'non-bullying'
        
#         return prediction
#     else:
#         return 'Model not available'


# import joblib
# import os
# import re
# from sklearn.feature_extraction.text import TfidfVectorizer
# from sklearn.linear_model import LogisticRegression
# from sklearn.pipeline import Pipeline
# from sklearn.model_selection import train_test_split
# from .models import ClassificationHistory
# import pandas as pd

# MODEL_PATH = os.path.join(os.path.dirname(__file__), 'model', 'bullying_detection_model.pkl')

# # Define your custom stop words
# my_stopwords = {'ku', 'iyo', 'uu', 'ha', 'ma', 'laga', 'ugu', 'waa', 'in', 'ee', 'aa', 'u', 'scw', 'si',
#                 'inay', 'la', 'ah', 'ka', 'ayaa', 'iska', 'wax', 'oo', 'soo', 'ayuu', 'bal', 'uga', 'aan',
#                 'wa', 'i', 'buu', 'inu', 'loo', 'waxaa', 'waxaan', 'ah', 'lama', 'maxay', 'tahay',
#                 'a', 'lagu', 'maxaa', 'inuu', 'wada', 'wuxuu', 'hala', 'e', 'waxan', 'sida', 'aad', 'kale', 
#                 'ah', 'wuu', 'ama', 'sii', 'hadii', 'ay', 'aya', 'siduu', 'yaa', 'ayu', 'way', 'naga', 'war',
#                 'ba', 'aha', 'iga', 'baa', 'ay', 'muxuu', 'maa', 'is', 'ayay', 'so', 'laha', 'haka', 'aya', 'wuxu',
#                 'haa', 'he', 'ilaa', 'hada', 'mida', 'may', 'waxa', 'waan', 'hadaad', 'waxay', 'kuma', 'wixii', 
#                 'inaad', 'og', 'sow', 'inta', 'haku', 'lahaa', 'inay', 'alx', 'kugu', 'yahay', 'kaa', 'miyaa',
#                 'miya', 'ayey', 'maxa', 'haduu', 'leh', 'ayan', 'hadi', 'iney', 'isku', 'lkn', 'alle', 'na', 'kuu'}

# # Function to preprocess text
# # detection/model.py

# def preprocess_text(text):
#     if not isinstance(text, str):
#         return ""
#     text = re.sub('[^a-zA-Z]', ' ', text)
#     text = text.lower().split()
#     text = [word for word in text if word not in my_stopwords]
#     return ' '.join(text)

# def train_model(data_path):
#     import pandas as pd

#     # Load data
#     data = pd.read_excel(data_path)
#     print("the data columns are : ", data.columns)

#     # Fill NaN values with empty strings
#     data['Erayada'] = data['Erayada'].astype(str).fillna('')

#     # Apply preprocessing
#     data['ProcessedStatement'] = data['Erayada'].apply(preprocess_text)

#     # Continue with the rest of your code
#     # Mapping labels
#     data['sentiment'] = data['label'].map({1: 'bullying', 0: 'non-bullying'})

#     # Split data into features and labels
#     X = data['ProcessedStatement']
#     y = data['sentiment'].map({'non-bullying': 0, 'bullying': 1})  # Update label mapping

#     # Split the dataset into training and testing sets
#     from sklearn.model_selection import train_test_split
#     X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

#     # Define a machine learning pipeline
#     from sklearn.pipeline import Pipeline
#     from sklearn.feature_extraction.text import TfidfVectorizer
#     from sklearn.linear_model import LogisticRegression

#     pipeline = Pipeline([
#         ('tfidf', TfidfVectorizer(lowercase=True)),
#         ('classifier', LogisticRegression(random_state=42, warm_start=True)),
#     ])

#     # Train the model
#     pipeline.fit(X_train, y_train)

#     # Save the trained pipeline
#     joblib.dump(pipeline, MODEL_PATH)

#     print("Model trained and saved.")

# # Load the model
# if os.path.exists(MODEL_PATH):
#     pipeline = joblib.load(MODEL_PATH)
# else:
#     pipeline = None

# def detect_bullying(text):
#     if pipeline:
#         processed_text = preprocess_text(text)
#         history_entry = ClassificationHistory.objects.filter(text=processed_text).first()
        
#         if history_entry and not history_entry.correct:
#             prediction = history_entry.corrected_prediction
#             history_entry.correct = False
#             history_entry.save()
#         else:
#             prediction = pipeline.predict([processed_text])[0]
#             prediction = 'bullying' if prediction == 1 else 'non-bullying'
        
#         return prediction
#     else:
#         return 'Model not available'
import joblib
import os
import re
from .models import ClassificationHistory

MODEL_PATH = os.path.join(os.path.dirname(__file__), 'model', 'bullying_detection_model.pkl')

# Define your custom stop words
my_stopwords = {'ku', 'iyo', 'uu', 'ha', 'ma', 'laga', 'ugu', 'waa', 'in', 'ee', 'aa', 'u', 'scw', 'si',
                'inay', 'la', 'ah', 'ka', 'ayaa', 'iska', 'wax', 'oo', 'soo', 'ayuu', 'bal', 'uga', 'aan',
                'wa', 'i', 'buu', 'inu', 'loo', 'waxaa', 'waxaan', 'ah', 'lama', 'maxay', 'tahay',
                'a', 'lagu', 'maxaa', 'inuu', 'wada', 'wuxuu', 'hala', 'e', 'waxan', 'sida', 'aad', 'kale', 
                'ah', 'wuu', 'ama', 'sii', 'hadii', 'ay', 'aya', 'siduu', 'yaa', 'ayu', 'way', 'naga', 'war',
                'ba', 'aha', 'iga', 'baa', 'ay', 'muxuu', 'maa', 'is', 'ayay', 'so', 'laha', 'haka', 'aya', 'wuxu',
                'haa', 'he', 'ilaa', 'hada', 'mida', 'may', 'waxa', 'waan', 'hadaad', 'waxay', 'kuma', 'wixii', 
                'inaad', 'og', 'sow', 'inta', 'haku', 'lahaa', 'inay', 'alx', 'kugu', 'yahay', 'kaa', 'miyaa',
                'miya', 'ayey', 'maxa', 'haduu', 'leh', 'ayan', 'hadi', 'iney', 'isku', 'lkn', 'alle', 'na', 'kuu'}

# Function to preprocess text
def preprocess_text(text):
    if not isinstance(text, str):
        return ""
    text = re.sub('[^a-zA-Z]', ' ', text)
    text = text.lower().split()
    text = [word for word in text if word not in my_stopwords]
    return ' '.join(text)

# Load the model
if os.path.exists(MODEL_PATH):
    pipeline = joblib.load(MODEL_PATH)
else:
    pipeline = None

def detect_bullying(text):
    if pipeline:
        processed_text = preprocess_text(text)
        history_entry = ClassificationHistory.objects.filter(text=processed_text).first()
        
        if history_entry and not history_entry.correct:
            prediction = history_entry.corrected_prediction
            history_entry.correct = True  # Mark as correct now
            history_entry.save()
        else:
            prediction = pipeline.predict([processed_text])[0]
            prediction = 'bullying' if prediction == 1 else 'non-bullying'
        
        return prediction
    else:
        return 'Model not available'
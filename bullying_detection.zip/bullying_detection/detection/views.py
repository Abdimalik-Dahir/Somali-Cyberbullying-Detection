import re
from django.shortcuts import render, redirect
from .model import detect_bullying, preprocess_text, pipeline, MODEL_PATH
from .models import ClassificationHistory
from django.urls import reverse
import joblib

# Define your custom stop words
my_stopwords = {'ku', 'iyo', 'uu', 'ha', 'ma', 'laga', 'ugu', 'waa', 'in', 'ee', 'aa', 'u', 'scw', 'si',
                'inay', 'la', 'ah', 'ka', 'ayaa', 'iska', 'wax', 'oo', 'soo', 'ayuu', 'bal', 'uga', 'aan',
                'wa', 'i', 'buu', 'inu', 'loo', 'waxaa', 'waxaan', 'ah', 'lama', 'maxay', 'tahay',
                'a', 'lagu', 'maxaa', 'inuu', 'wada', 'wuxuu', 'hala', 'e', 'waxan', 'sida', 'aad', 'kale', 
                'ah', 'wuu', 'ama', 'sii', 'hadii', 'ay', 'aya', 'siduu', 'yaa', 'ayu', 'way', 'naga', 'war',
                'ba', 'aha', 'iga', 'baa', 'ay', 'muxuu', 'maa', 'is', 'ayay', 'so', 'laha', 'haka', 'aya', 'wuxu',
                'haa', 'he', 'ilaa', 'hada', 'mida', 'may', 'waxa', 'waan', 'hadaad', 'waxay', 'kuma', 'wixii', 
                'inaad', 'og', 'sow', 'inta', 'haku', 'lahaa', 'inay', 'alx', 'kugu', 'yahay', 'kaa', 'miyaa',
                'miya', 'ayey', 'maxa', 'haduu', 'leh', 'ayan', 'hadi', 'iney', 'isku', 'lkn', 'alle', 'na', 'kuu'}

# Function to preprocess text (included here for clarity)
def preprocess_text(text):
    if not isinstance(text, str):
        return ""
    text = re.sub('[^a-zA-Z]', ' ', text)
    text = text.lower().split()
    text = [word for word in text if word not in my_stopwords]
    return ' '.join(text)

def home(request):
    if request.method == "POST":
        text = request.POST.get('text')
        processed_text = preprocess_text(text)
        history_entry = ClassificationHistory.objects.filter(text=processed_text).first()

        if history_entry and not history_entry.correct:
            prediction = history_entry.corrected_prediction
        else:
            prediction = detect_bullying(processed_text)
        
        # Save the new prediction as a new entry
        ClassificationHistory.objects.create(text=processed_text, prediction=prediction)

        return redirect('history')
    return render(request, 'detection/home.html')

def history(request):
    history = ClassificationHistory.objects.all()
    return render(request, 'detection/history.html', {'history': history})

def update_classification(request, pk, correct):
    entry = ClassificationHistory.objects.get(pk=pk)
    entry.correct = correct == 'true'

    # Change prediction based on feedback
    if entry.prediction == 'bullying' and not entry.correct:
        new_label = 0  # non-bullying
        new_prediction = 'non-bullying'
    elif entry.prediction == 'non-bullying' and not entry.correct:
        new_label = 1  # bullying
        new_prediction = 'bullying'
    else:
        new_label = 1 if entry.prediction == 'bullying' else 0
        new_prediction = entry.prediction

    # Log the updates
    print(f"Updating model with text: {entry.text}, new label: {new_label}")

    # Process and transform the new data
    X_new = [preprocess_text(entry.text)]
    y_new = [new_label]

    # Access the estimator inside the pipeline
    if hasattr(pipeline.named_steps['classifier'], 'partial_fit'):
        # Transform new data
        X_new_transformed = pipeline.named_steps['tfidf'].transform(X_new)

        # Update the classifier with partial_fit
        pipeline.named_steps['classifier'].partial_fit(X_new_transformed, y_new, classes=[0, 1])

        # Save the updated pipeline
        joblib.dump(pipeline, MODEL_PATH)
        print("Model updated and saved.")

    # Update the prediction in the history
    entry.prediction = new_prediction
    entry.corrected_prediction = new_prediction
    entry.save()

    return redirect(reverse('history'))

def delete(request):
    if request.method == "POST":
        delete_option = request.POST.get('delete')
        if delete_option == "selected":
            ids_to_delete = request.POST.getlist('ids')
            ClassificationHistory.objects.filter(id__in=ids_to_delete).delete()
        elif delete_option == "all":
            ClassificationHistory.objects.all().delete()
        return redirect('history')
    history = ClassificationHistory.objects.all()
    return render(request, 'detection/delete.html', {'history': history})

# models.py
from django.db import models

class ClassificationHistory(models.Model):
    text = models.TextField()
    prediction = models.CharField(max_length=50)
    correct = models.BooleanField(default=True)
    corrected_prediction = models.CharField(max_length=50, null=True, blank=True)

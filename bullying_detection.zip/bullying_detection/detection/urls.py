# detection/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('history/', views.history, name='history'),
    path('update/<int:pk>/<str:correct>/', views.update_classification, name='update_classification'),
    path('update_classification/<int:pk>/<str:correct>/', views.update_classification, name='update_classification'),
    path('delete/', views.delete, name='delete'),
]
